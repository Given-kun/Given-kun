
<html>
<head>
	 <style>
    H1{
    -webkit-text-stroke-width: 1px;
 -webkit-text-stroke-color: black;

 H2{
 	display: inline-block;
  color: black;
  text-transform: uppercase;
  font-family: Arial;
  border: 2px solid White;
  display: inline-block;
  color: black;
  text-transform: uppercase;
  letter-spacing: 4px;
  text-decoration: none;
  font-size: 15px;
  overflow: hidden;
  transition: 0.2s;
  color: White;
  background: #242526;
  font-family: Segoe UI;
 }


  }
    input[type='radio']:after {
        width: 9px;
        height: 9px;
        border-radius: 15px;
        top: -2px;
        left: -1px;
        position: relative;
        background-color: #d1d3d1;
        content: '';
        display: inline-block;
        visibility: visible;
        border: 2px solid white;
    }
      input[type='radio']:checked:after {
        width: 9px;
        height: px;
        border-radius: 15px;
        top: -2px;
        left: -1px;
        position: relative;
        background-color: #ffa500;
        content: '';
        display: inline-block;
        visibility: visible;
        border: 2px solid white;
    }
    body{
    background: #18191a;
  }
    table{
  display: inline-block;
  color: black;
  text-transform: uppercase;
  font-family: Arial;
  border: 2px solid White;
  display: inline-block;
  color: black;
  text-transform: uppercase;
  letter-spacing: 4px;
  text-decoration: none;
  font-size: 15px;
  overflow: hidden;
  transition: 0.2s;
  color: White;
  background: #242526;
  font-family: Segoe UI;


   }
   p{
   display: inline-block;
  padding: 15px 30px;
  color: black;
  text-transform: uppercase;
  font-family: Arial;
  border: 1px solid White;
  display: inline-block;
  padding: 15px 30px;
  color: black;
  text-transform: uppercase;
  letter-spacing: 4px;
  text-decoration: none;
  font-size: 15px;
  overflow: hidden;
  transition: 0.2s;
  color: White;
  background: #242526;
  font-family: Segoe UI;

   }
   H3{
  text-transform: uppercase;
  letter-spacing: 4px;
  text-decoration: none;
  font-size: 15px;
  overflow: hidden;
  transition: 0.2s;
  color: White;
  -webkit-text-stroke-width: 1px;
 -webkit-text-stroke-color: red;
  font-weight: bold;
    font-family: Segoe UI;
    justify-content: center;

}
 H4{
  text-transform: uppercase;
  letter-spacing: 4px;
  text-decoration: none;
  font-size: 13px;
  overflow: hidden;
  transition: 0.2s;
  color: White;
  -webkit-text-stroke-width: 1px;
 -webkit-text-stroke-color: red;
  font-weight: bold;
    font-family: Segoe UI;
    justify-content: center;

}
body{
  margin: 0;
  padding:0;
  box-sizing: border-box;
}
.container
{
    width:300%;
  height: 300px;
  background: #b0b3b8;
}
.header{
  width:100%;
  height: 100px;
  background: #006491;
  font-family: One Dot Condensed Bold,Arial Narrow,Arial,Helvetica,sans-serif;
  color: #fff;
     font-size: .875rem;
    letter-spacing: .05rem;
    line-height: 1rem;
    min-width: 12.375rem;
    padding: .1875rem .5rem .1875rem 4rem;
    text-transform: uppercase;
    -webkit-font-smoothing: antialiased;
    display: flex;
        text-align: center;

 
}
  input {

background: #b0b3b8;

color: black;

border-style: outset;

border-color:   #3a3b3c;

height: auto;

width: auto;

  font-family: Segoe UI;

text-shadow:none;


  text-decoration: none;
  
}

a{
		border: 1px solid #e4e6eb;
	display: inline-block;
	padding: 15px 30px;
	color: black;
	text-transform: uppercase;
	letter-spacing: 4px;
	text-decoration: none;
	font-size: 24px;
	overflow: hidden;
	transition: 0.2s;
	color: White;
	background: #242526;
	font-family: Segoe UI;
	}
  </style>
</head>
<body>
 <div class="header">
    <img src="image.png" height="100" width="100" position="margin-right" alt="GIVEN-KUN">
   <center> <H1>GIVEN-KUN's PIZZRIA ORDER ONLINE</H1><hr> </center>
 </div> 
 <h3>#01 Given-kun Pizzeria Street</h3>
 <h4>Tel #:734-930-3030</h4>

<p>Your order has been sent to Given-kun's Pizzeria<br>
Thank you our dear Customer for patronizng our special and delicious pizza...<br>
<b>Waiting time:</b>20 - 30 minutes or will
	get 10% discount for late delivery</p>
<br>
	<a href="MP01_ValenzuelaGiven.php">Back to Home</a>
	<a href="ReservationValenzuelaGiven.php">🏢</a>

</body>
</html>